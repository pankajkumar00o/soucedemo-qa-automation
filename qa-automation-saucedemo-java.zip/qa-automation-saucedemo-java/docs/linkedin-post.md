## LinkedIn post draft

I built a small UI automation testing project using **Java, Selenium WebDriver, TestNG, and Maven**.

The tests cover a few key flows on the SauceDemo practice website:
- Successful login and locked-out user validation
- Adding a product to the cart
- Sorting products by price (low to high)

I organized the tests with the **Page Object Model**, used explicit waits, and configured headless browser execution. This was a hands-on way to practice writing and maintaining UI tests.

**Tools:** Java | Selenium | TestNG | Maven

#SoftwareTesting #QA #AutomationTesting #Selenium #Java #TestNG

> Before posting, add your repository link (after you upload the project to GitHub) and, if you like, a screenshot of a successful test run.
