# Test cases

| ID | Scenario | Test data | Expected result |
|---|---|---|---|
| TC-01 | Login with a valid user | `standard_user` / `secret_sauce` | User lands on the Products page. |
| TC-02 | Login with a locked-out user | `locked_out_user` / `secret_sauce` | A locked-out error message is displayed. |
| TC-03 | Add a product to the cart | `Sauce Labs Backpack` | Cart badge shows `1`; cart contains the selected product. |
| TC-04 | Sort products by price ascending | Sort option: Price (low to high) | `Sauce Labs Onesie` appears first. |

The tests use the public SauceDemo practice site. They require network access and the site to be available.
